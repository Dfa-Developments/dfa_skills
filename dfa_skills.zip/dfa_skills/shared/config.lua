Config = {}

Config.UsingCommand = true -- If you want to use the command to check your skills, set this to true

Config.Skills = {
    'weaponsmith',
    'blacksmith',
    'delivery',
    'hunting',
    'crafting',
    'construction'
}
