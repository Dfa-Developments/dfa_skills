ALTER table players
	ADD COLUMN `skills` LONGTEXT DEFAULT '[]';