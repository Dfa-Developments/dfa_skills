export interface Skill {
  name: string;
  level: number;
  progress: number;
}
