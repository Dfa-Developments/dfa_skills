import App from "./App.svelte";
import "./styles/globals.css";

const app = new App({
  target: document.getElementById("app"),
});

export default app;
